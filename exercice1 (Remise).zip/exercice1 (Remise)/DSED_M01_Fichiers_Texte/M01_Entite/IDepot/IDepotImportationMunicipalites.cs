namespace M01_Entite.IDepot;

public interface IDepotImportationMunicipalites
{
    IEnumerable<MunicipaliteEntite> LireMunicipalites();
}